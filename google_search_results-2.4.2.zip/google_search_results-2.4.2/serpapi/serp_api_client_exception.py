class SerpApiClientException(Exception):
    pass